#include <iostream>
#include <fstream>
#include "Header.h"
#include <string>
using namespace std;

typedef long long int ll;
#define len(a) (ll)a.size()


struct Node {
	ll value;
	Node* next;

	Node() {}
	Node(ll _value) {
		value = _value;
		next = nullptr;
	}
};


void push(Node*& root, ll value) {
	Node* NewNode = new Node(value);

	if (root == nullptr)
		root = NewNode;
	else {
		NewNode->next = root;
		root = NewNode;
	}
}


ll* peek(Node* root) {
	if (root == nullptr)
		return nullptr;
	return &root->value;
}


bool pop(Node*& root) {
	if (root == nullptr)
		return false;

	Node* NewNode = root;
	root = root->next;
	delete NewNode;
	return true;
}

void clear(Node*& root) {
	while (root != nullptr) {
		Node* NewNode = root;
		root = root->next;
		delete NewNode;
	}
}

string Show(Node* root) {
	Node* tmp = root;
	string res = "";
	while (tmp != nullptr) {
		cout << to_string(tmp->value + 1) + " ";
		tmp = tmp->next;
	}

	delete tmp;
	return res;
}

// (), [], {}, <>

void bracket(string s) {

	char open[4];
	char close[4];
	open[0] = '(';
	open[1] = '[';
	open[2] = '{';
	open[3] = '<';

	close[0] = ')';
	close[1] = ']';
	close[2] = '}';
	close[3] = '>';

	Node* root = nullptr;

	bool er = false;

	string WrongPairBracket = "";
	string Wrong = "";
	for (int i = 0; i < len(s); ++i) {
		ll id = -1;
		for (int j = 0; j < 4; ++j) {
			if (close[j] == s[i])
				id = j;
		}

		if (id == -1) {
			for (int j = 0; j < 4; ++j) {
				if (open[j] == s[i])
					id = j;
			}
			if (id != -1) {
				push(root, i);
			}
		}
		else {
			if (root != nullptr && open[id] == s[*peek(root)]) {
				pop(root);
			}
			else if (root != nullptr) {
				er = true;
				WrongPairBracket += to_string(*peek(root) + 1) + ' ' + to_string(i + 1) + " | ";
				pop(root);
			}
			else if (root == nullptr) {
				er = true;
				Wrong += to_string(i + 1) + ' ';
			}
		}
	}

	if (er || peek(root) != nullptr) {
		cout << "<div>" + s + "</div>";
		cout << "<div>Error\n<\div>";
		if (len(WrongPairBracket) != 0) {
			cout << "<div>Wrong pair:\n</div>"; cout << WrongPairBracket;
		}

		if (len(Wrong) != 0 || peek(root) != nullptr)
			cout << "<div>Unnecessary brackets:\n</div>";
		if (len(Wrong) != 0)
			cout << Wrong + "\n";
		if (peek(root) != nullptr) {
			// cout << "2 ";
			Show(root);
		}
	}
	else
		cout << "<div>No errors detected</div>";
}

void show_content();
void show_menu();
void show_header();

void main() {
	cout << "Content-type: text/html; charset=Windows-1251\n\n";
	ifstream f("_index");
	if (f.is_open())
	{
		auto sz = 65536;
		auto buf = new char[sz];
		while (!f.eof()) {
			f.getline(buf, sz);
			if (strcmp(buf, "<!--#content#-->") == 0) {
				show_content();
			}
			else if (!strcmp(buf, "<!--#navbar#-->"))
			{
				show_menu();
			}
			else if (!strcmp(buf, "<!--#header#-->"))
			{
				show_header();
			}
			cout << buf;
		}
		delete[] buf;
		f.close();
	}
	else {
		cout << "�� ������� ������� ��������";
	}
}
void show_header()
{
	cout << "<h1>Website IlnVal</h1>";
	cout << "<p>A website created by Ilnur Valeev.</p>";
}
void show_menu()
{
	ifstream f("navbar");
	if (f.is_open())
	{
		auto sz = 65536;
		auto buf = new char[sz];
		while (!f.eof())
		{
			f.getline(buf, sz);
			cout << buf;
		}
	}
	f.close();
}
void show_content()
{

#ifndef _DEBUG
	char* data = nullptr;
	get_form_data(data);
#else
	const char* data = "imya=Sergey&email=a%40b.ru";
#endif
	char* str = new char[50];


	if (data && strlen(data) > 0)
	{
		char* value = nullptr;
		get_param_value(value, "expression", data);
		str = value;
	}
	cout << "<form method='get' action='IlnVal.cgi'>";
	cout << "������� �������������� ���������: <input type='text' name='expression' maxlength='50' size='50'><br>";
	cout << "<input type='submit' value='���������'>";
	cout << "</form>";
	string res = "";
	for (int i = 0; i <= strlen(str); i++)
		res += str[i];

	bracket(res);
	delete[] data;
}